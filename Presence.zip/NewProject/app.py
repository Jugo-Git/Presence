from http.server import BaseHTTPRequestHandler, HTTPServer
import sqlite3
import datetime
import urllib.parse
import bcrypt

def init_db():
    with sqlite3.connect('db_presence.db') as conn:
        conn.executescript('''
            CREATE TABLE IF NOT EXISTS users(
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_last_name TEXT NOT NULL,
                user_first_name TEXT NOT NULL,
                user_email TEXT NOT NULL UNIQUE,
                user_phone TEXT NOT NULL UNIQUE,
                user_password TEXT NOT NULL,
                user_created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                user_updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                user_valid INTEGER
            );

            CREATE TABLE IF NOT EXISTS logs(
                log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                log_user_id INTEGER NOT NULL,
                log_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (log_user_id) REFERENCES users(user_id)
            );

            CREATE TABLE IF NOT EXISTS roles(
                role_id INTEGER PRIMARY KEY AUTOINCREMENT,
                role_user_id INTEGER NOT NULL,
                create_role_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                role_name TEXT,
                role_valid INTEGER,
                FOREIGN KEY (role_user_id) REFERENCES users(user_id)
            );
        ''')

class RequestHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        if self.path == '/':
            self.serve_index()
        elif self.path == '/auth.html':
            self.serve_page('templates/auth.html')
        elif self.path == '/add-user.html':
            self.serve_page('templates/add-user.html')
        elif self.path == '/add-admin.html':
            self.serve_page('templates/add-admin.html')
        elif self.path == '/personnel-list.html':
            self.serve_personnel_list()
        elif self.path == '/daily-presence.html':
            self.serve_daily_presence()
        elif self.path.startswith('/static/'):
            self.serve_static()
        else:
            self.send_response(404)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(b'Page not found.')

    def do_POST(self):
        if self.path == '/auth':
            self.handle_auth()
        elif self.path == '/add-user':
            self.handle_add_user()
        elif self.path == '/add-admin':
            self.handle_add_admin()
        else:
            self.send_response(404)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()

    def serve_index(self):
        conn = sqlite3.connect('db_presence.db')
        cursor = conn.cursor()
        cursor.execute("SELECT user_last_name, user_first_name, user_email, user_phone FROM users")
        personnel_list = cursor.fetchall()
        conn.close()

        try:
            with open('templates/index.html', 'r') as file:
                html_template = file.read()
        except FileNotFoundError:
            self.send_response(404)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(b'Index template not found.')
            return

        personnel_rows = ''.join(f'''
        <tr>
            <td>{emp[0]}</td>
            <td>{emp[1]}</td>
            <td>{emp[2]}</td>
            <td>{emp[3]}</td>
        </tr>
        ''' for emp in personnel_list)

        html = html_template.replace("<!-- DATA_ROWS -->", personnel_rows)

        self.send_response(200)
        self.send_header('Content-Type', 'text/html')
        self.end_headers()
        self.wfile.write(html.encode())

    def serve_static(self):
        file_path = self.path[1:]
        try:
            with open(file_path, 'rb') as file:
                self.send_response(200)
                if file_path.endswith('.css'):
                    self.send_header('Content-Type', 'text/css')
                elif file_path.endswith('.js'):
                    self.send_header('Content-Type', 'application/javascript')
                self.end_headers()
                self.wfile.write(file.read())
        except FileNotFoundError:
            self.send_response(404)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(b'Static file not found.')

    def serve_personnel_list(self):
        self.serve_index()

    def serve_daily_presence(self):
        conn = sqlite3.connect('db_presence.db')
        cursor = conn.cursor()
        today = datetime.datetime.now().date()
        cursor.execute('''
            SELECT user_last_name, user_first_name, user_email, log_at
            FROM logs
            JOIN users ON logs.log_user_id = users.user_id
            WHERE DATE(log_at) = ?
        ''', (today,))
        daily_presence = cursor.fetchall()
        conn.close()

        try:
            with open('templates/daily-presence.html', 'r') as file:
                html_template = file.read()
        except FileNotFoundError:
            self.send_response(404)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(b'Daily presence template not found.')
            return

        presence_rows = ''.join(f'''
        <tr>
            <td>{emp[0]}</td>
            <td>{emp[1]}</td>
            <td>{emp[2]}</td>
            <td>{emp[3]}</td>
        </tr>
        ''' for emp in daily_presence)

        html = html_template.replace("<!-- DATA_ROWS -->", presence_rows)

        self.send_response(200)
        self.send_header('Content-Type', 'text/html')
        self.end_headers()
        self.wfile.write(html.encode())

    def handle_auth(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        post_data = urllib.parse.parse_qs(post_data.decode())

        email = post_data.get('email', [''])[0]
        password = post_data.get('password', [''])[0]

        if not email or not password:
            self.send_response(400)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(b'Email and password are required.')
            return

        try:
            conn = sqlite3.connect('db_presence.db')
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT user_id, user_password, user_valid
                FROM users
                WHERE user_email = ?
            ''', (email,))
            user = cursor.fetchone()

            if user and bcrypt.checkpw(password.encode(), user[1]):
                cursor.execute('''
                    SELECT role_name FROM roles
                    WHERE role_user_id = ? AND role_valid = 1
                ''', (user[0],))
                roles = cursor.fetchall()

                if ('admin',) in roles:
                    self.send_response(302)
                    self.send_header('Location', '/daily-presence.html')
                else:
                    self.send_response(302)
                    self.send_header('Location', '/')
                self.end_headers()
            else:
                self.send_response(401)
                self.send_header('Content-Type', 'text/html')
                self.end_headers()
                self.wfile.write(b'Invalid email or password.')
        except sqlite3.Error as e:
            self.send_response(500)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(f'Internal server error: {e}'.encode())

    def handle_add_user(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        post_data = urllib.parse.parse_qs(post_data.decode())

        user_last_name = post_data.get('user_last_name', [''])[0]
        user_first_name = post_data.get('user_first_name', [''])[0]
        user_email = post_data.get('user_email', [''])[0]
        user_phone = post_data.get('user_phone', [''])[0]
        user_password = post_data.get('user_password', [''])[0]
        user_valid = post_data.get('user_valid', ['1'])[0] == '1'

        hashed_password = bcrypt.hashpw(user_password.encode(), bcrypt.gensalt())

        try:
            conn = sqlite3.connect('db_presence.db')
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO users (
                    user_last_name,
                    user_first_name,
                    user_email,
                    user_phone,
                    user_password,
                    user_created_at,
                    user_updated_at,
                    user_valid
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                user_last_name,
                user_first_name,
                user_email,
                user_phone,
                hashed_password,
                datetime.datetime.now(),
                datetime.datetime.now(),
                user_valid
            ))
            conn.commit()
            conn.close()
            self.send_response(302)
            self.send_header('Location', '/')
            self.end_headers()
        except sqlite3.IntegrityError as e:
            self.send_response(500)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(f'Error adding user: {e}'.encode())

    def handle_add_admin(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        post_data = urllib.parse.parse_qs(post_data.decode())

        user_last_name = post_data.get('user_last_name', [''])[0]
        user_first_name = post_data.get('user_first_name', [''])[0]
        user_email = post_data.get('user_email', [''])[0]
        user_phone = post_data.get('user_phone', [''])[0]
        user_password = post_data.get('user_password', [''])[0]

        hashed_password = bcrypt.hashpw(user_password.encode(), bcrypt.gensalt())

        try:
            conn = sqlite3.connect('db_presence.db')
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO users (
                    user_last_name,
                    user_first_name,
                    user_email,
                    user_phone,
                    user_password,
                    user_created_at,
                    user_updated_at,
                    user_valid
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                user_last_name,
                user_first_name,
                user_email,
                user_phone,
                hashed_password,
                datetime.datetime.now(),
                datetime.datetime.now(),
                1  # Mark as valid
            ))
            user_id = cursor.lastrowid

            # Add the admin role to the new user
            cursor.execute('''
                INSERT INTO roles (
                    role_user_id,
                    create_role_at,
                    role_name,
                    role_valid
                ) VALUES (?, ?, ?, ?)
            ''', (user_id, datetime.datetime.now(), 'admin', 1))

            conn.commit()
            conn.close()
            self.send_response(302)
            self.send_header('Location', '/')
            self.end_headers()
        except sqlite3.IntegrityError as e:
            self.send_response(500)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(f'Error adding admin: {e}'.encode())

if __name__ == "__main__":
    init_db()
    server_address = ('', 8000)
    httpd = HTTPServer(server_address, RequestHandler)
    print("Starting httpd server on port 8000")
    httpd.serve_forever()
